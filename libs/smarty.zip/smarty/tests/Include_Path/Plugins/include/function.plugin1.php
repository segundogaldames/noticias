<?php
function smarty_function_plugin1($params, $template)
{
    return 'plugin1';
}
