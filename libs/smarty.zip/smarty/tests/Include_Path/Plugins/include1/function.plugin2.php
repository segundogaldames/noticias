<?php
function smarty_function_plugin2($params, $template)
{
    return 'plugin2';
}
