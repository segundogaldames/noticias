<?php
function default_script_modifier($input, $text = null)
{
    return $text . $input;
}
