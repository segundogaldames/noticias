<?php
function default_script_function_tag($params, $template)
{
    return 'scriptfunction ' . $params['value'];
}
