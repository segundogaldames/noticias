<?php
function smarty_function_plugin3($params, $template)
{
    return 'plugin3';
}
