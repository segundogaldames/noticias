<?php
function smarty_function_chain3($params, $tpl)
{
    return 'from chain3';
}
