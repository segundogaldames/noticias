#! /bin/bash
vendor/phpunit/phpunit/phpunit
